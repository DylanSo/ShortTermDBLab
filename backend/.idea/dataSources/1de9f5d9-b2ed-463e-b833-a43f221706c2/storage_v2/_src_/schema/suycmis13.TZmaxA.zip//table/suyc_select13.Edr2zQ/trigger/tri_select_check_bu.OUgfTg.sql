create definer = root@localhost trigger tri_select_check_bu
    before update
    on suyc_select13
    for each row
BEGIN
	DECLARE msg varchar(100);
 
	IF NEW.syc_ifRevamp13 != '首次修读' AND NEW.syc_ifRevamp13 != '重修'
	THEN
		SET msg = CONCAT('您输入的修读情况：',NEW.syc_ifRevamp13,' 无效，请输入"首次修读"或"重修"。');
		SIGNAL SQLSTATE 'SE101' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_grade13  < 0 OR NEW.syc_grade13  > 100
	THEN
		SET msg = CONCAT('您输入的成绩：',NEW.syc_grade13,' 为无效的成绩，请输入大于等于、小于等于100的值。');
		SIGNAL SQLSTATE 'SE102' SET MESSAGE_TEXT = msg;
	END IF;
END;

