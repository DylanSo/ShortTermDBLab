create definer = root@localhost trigger tri_teach_bi
    before insert
    on suyc_teach13
    for each row
BEGIN
	SET NEW.syc_teno13 = CONCAT('A', SUBSTR(NEW.syc_cono13,2,6), RIGHT(NEW.syc_cno13,2));
	
	UPDATE suyc_course13 SET syc_coifOptional13 = '可选'
	WHERE suyc_course13.syc_cono13 = NEW.syc_cono13;
	
END;

