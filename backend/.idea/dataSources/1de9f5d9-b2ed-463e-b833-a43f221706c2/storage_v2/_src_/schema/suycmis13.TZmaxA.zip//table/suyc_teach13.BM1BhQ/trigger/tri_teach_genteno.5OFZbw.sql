create definer = root@localhost trigger tri_teach_genTeno
    before insert
    on suyc_teach13
    for each row
BEGIN
	SET NEW.syc_teno13 = CONCAT('A', SUBSTR(NEW.syc_cono13,2,6), RIGHT(NEW.syc_cno13,2));
END;

