create definer = root@localhost trigger tri_t_check_bi
    before insert
    on suyc_teacher13
    for each row
BEGIN
	DECLARE msg varchar(100);
 
	IF NEW.syc_tsex13 != '男' AND NEW.syc_tsex13 != '女'
	THEN
		SET msg = CONCAT('您输入的性别：',NEW.syc_tsex13,' 为无效的性别，请输入"男"或"女"。');
		SIGNAL SQLSTATE 'TC001' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_tage13  < 0
	THEN
		SET msg = CONCAT('您输入的年龄：',NEW.syc_tage13,' 为无效的年龄，请输入大于等于0的值。');
		SIGNAL SQLSTATE 'TC002' SET MESSAGE_TEXT = msg;
	END IF;
	IF (LENGTH(NEW.syc_tphone13)  > 11) OR (LENGTH(0+NEW.syc_tphone13) != LENGTH(NEW.syc_tphone13))
	THEN
		SET msg = CONCAT('您输入的电话号码：',NEW.syc_tphone13,' 为无效的号码，请输入长度小于11的纯数字值。');
		SIGNAL SQLSTATE 'TC003' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_temail13 NOT LIKE '%@%'
	THEN
		SET msg = CONCAT('您输入的邮箱：',NEW.syc_temail13,' 为无效的邮箱，请输入格式正确的邮箱。');
		SIGNAL SQLSTATE 'TC004' SET MESSAGE_TEXT = msg;
	END IF;
END;

