create definer = root@localhost view suyc_teach_able13 as
select `suycmis13`.`suyc_course13`.`syc_coname13`       AS `syc_coname13`,
       `suycmis13`.`suyc_course13`.`syc_semester13`     AS `syc_semester13`,
       `suycmis13`.`suyc_teacher13`.`syc_tname13`       AS `syc_tname13`,
       `suycmis13`.`suyc_teacher13`.`syc_title13`       AS `syc_title13`,
       `suycmis13`.`suyc_teach13`.`syc_classtime13`     AS `syc_classtime13`,
       `suycmis13`.`suyc_teach13`.`syc_teplace13`       AS `syc_teplace13`,
       `suycmis13`.`suyc_course13`.`syc_mno13`          AS `syc_mno13`,
       `suycmis13`.`suyc_course13`.`syc_cocredit13`     AS `syc_cocredit13`,
       `suycmis13`.`suyc_course13`.`syc_cohours13`      AS `syc_cohours13`,
       `suycmis13`.`suyc_course13`.`syc_coassessment13` AS `syc_coassessment13`,
       `suycmis13`.`suyc_course13`.`syc_coifOptional13` AS `syc_coifOptional13`
from ((`suycmis13`.`suyc_teach13` join `suycmis13`.`suyc_teacher13` on ((`suycmis13`.`suyc_teach13`.`syc_tno13` =
                                                                         `suycmis13`.`suyc_teacher13`.`syc_tno13`)))
         join `suycmis13`.`suyc_course13`
              on ((`suycmis13`.`suyc_teach13`.`syc_cono13` = `suycmis13`.`suyc_course13`.`syc_cono13`)))
where (`suycmis13`.`suyc_course13`.`syc_coifOptional13` = '可选');

