create definer = root@localhost view suyc_stu_info13 as
select `suycmis13`.`suyc_student13`.`syc_sno13`        AS `syc_sno13`,
       `suycmis13`.`suyc_student13`.`syc_sname13`      AS `syc_sname13`,
       `suycmis13`.`suyc_student13`.`syc_ssex13`       AS `syc_ssex13`,
       `suycmis13`.`suyc_student13`.`syc_sage13`       AS `syc_sage13`,
       `suycmis13`.`suyc_student13`.`syc_source13`     AS `syc_source13`,
       `suycmis13`.`suyc_student13`.`syc_scredits13`   AS `syc_scredits13`,
       `suycmis13`.`suyc_student13`.`syc_ifgraduate13` AS `syc_ifgraduate13`,
       `suycmis13`.`suyc_major13`.`syc_mname13`        AS `syc_mname13`,
       `suycmis13`.`suyc_class13`.`syc_cname13`        AS `syc_cname13`,
       `suycmis13`.`suyc_dept13`.`syc_dname13`         AS `syc_dname13`
from (((`suycmis13`.`suyc_student13` join `suycmis13`.`suyc_major13` on ((`suycmis13`.`suyc_student13`.`syc_mno13` =
                                                                          `suycmis13`.`suyc_major13`.`syc_mno13`))) join `suycmis13`.`suyc_class13` on ((
        (`suycmis13`.`suyc_student13`.`syc_cno13` = `suycmis13`.`suyc_class13`.`syc_cno13`) and
        (`suycmis13`.`suyc_major13`.`syc_mno13` = `suycmis13`.`suyc_class13`.`syc_mno13`))))
         join `suycmis13`.`suyc_dept13`
              on ((`suycmis13`.`suyc_major13`.`syc_dno13` = `suycmis13`.`suyc_dept13`.`syc_dno13`)));

