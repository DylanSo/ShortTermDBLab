create definer = root@localhost trigger tri_course_check_bi
    before insert
    on suyc_course13
    for each row
BEGIN
	DECLARE msg varchar(100);
 
	IF NEW.syc_coassessment13 != '考试' AND NEW.syc_coassessment13 != '考查'
	THEN
		SET msg = CONCAT('您输入的考查方式：',NEW.syc_coassessment13,' 无效，请输入"考试"或"考查"。');
		SIGNAL SQLSTATE 'CO001' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_coifOptional13 != '可选' AND NEW.syc_coifOptional13 != '不可选'
	THEN
		SET msg = CONCAT('您输入的可选情况：',NEW.syc_coifOptional13,' 无效，请输入"可选"或"不可选"。');
		SIGNAL SQLSTATE 'CO002' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_cocredit13  < 0
	THEN
		SET msg = CONCAT('您输入的学分：',NEW.syc_cocredit13,' 为无效的学分，请输入大于等于0的值。');
		SIGNAL SQLSTATE 'CO003' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_cohours13  < 0
	THEN
		SET msg = CONCAT('您输入的学时：',NEW.syc_cohours13,' 为无效的学时，请输入大于等于0的值。');
		SIGNAL SQLSTATE 'CO004' SET MESSAGE_TEXT = msg;
	END IF;
END;

