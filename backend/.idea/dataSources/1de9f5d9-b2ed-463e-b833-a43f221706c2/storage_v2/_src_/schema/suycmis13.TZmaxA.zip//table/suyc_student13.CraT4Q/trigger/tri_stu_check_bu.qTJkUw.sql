create definer = root@localhost trigger tri_stu_check_bu
    before update
    on suyc_student13
    for each row
BEGIN
	DECLARE msg varchar(100);
 
	IF NEW.syc_ssex13 != '男' AND NEW.syc_ssex13 != '女'
	THEN
		SET msg = CONCAT('您输入的性别：',NEW.syc_ssex13,' 为无效的性别，请输入"男"或"女"。');
		SIGNAL SQLSTATE 'ST101' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_sage13  < 0
	THEN
		SET msg = CONCAT('您输入的年龄：',NEW.syc_sage13,' 为无效的年龄，请输入大于等于0的值。');
		SIGNAL SQLSTATE 'ST102' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_ifgraduate13 != '在读' AND NEW.syc_ifgraduate13 != '已毕业'
	THEN
		SET msg = CONCAT('您输入的在读信息：',NEW.syc_ifgraduate13,' 为无效的在读信息，请输入"在读"或"已毕业"。');
		SIGNAL SQLSTATE 'ST103' SET MESSAGE_TEXT = msg;
	END IF;
	IF NEW.syc_cno13 != OLD.syc_cno13
	THEN
		UPDATE suyc_class13 SET syc_snum13=syc_snum13-1 WHERE syc_cno13 = OLD.syc_cno13;
		UPDATE suyc_class13 SET syc_snum13=syc_snum13+1 WHERE syc_cno13 = NEW.syc_cno13;
	END IF;
	
END;

